var express = require('express');
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var fs = require('fs');

app.get('/', function(req, res){
    fs.readFile('./Webpage.html', function (err, html) {
         if (err) throw err; 
    app.use(express.static(__dirname + '/public'));
    app.use(express.static(__dirname));
    res.writeHeader(200, {"Content-Type": "text/html"});  
    res.write(html); 
    });


io.on('connection', function(socket){
  console.log('a user connected');
     socket.on('join', function(msg){
    console.log('message: ' + msg);
    
    var request = require('request'); // "Request" library

var client_id = '85bf095c00bf4bea9bb89fac34e1aa70'; // Your client id
var client_secret = '2542bc5c87124f0082acb2a4afa4b1c2'; // Your secret

// your application requests authorization
var authOptions = {
  url: 'https://accounts.spotify.com/api/token',
  headers: {
    'Authorization': 'Basic ' + (new Buffer(client_id + ':' + client_secret).toString('base64'))
  },
  form: {
    grant_type: 'client_credentials'
  },
  json: true
};

request.post(authOptions, function(error, response, body) {
  if (!error && response.statusCode === 200) {

    // use the access token to access the Spotify Web API
    var token = body.access_token;
    var options = {
      url: 'https://api.spotify.com/v1/search?q=' + msg + '&type=artist&limit=1&offset=0',
      headers: {
        'Authorization': 'Bearer ' + token
      },
      json: true
    };
    request.get(options, function(error, response, body) {
      //console.log(body);
      console.log("Artist info://%s",body.artists.items[0].popularity);
      
      var new_url = 'https://open.spotify.com/artist/' + body.artists.items[0].id;
      console.log(new_url);
      io.emit('message', new_url,body.artists.items[0].popularity);
    });
  }
});
    

         
         
         
    // io.emit('chat message', msg);
  });
   // url1 = '';
});

    });


var port = process.env.PORT || 3000;
http.listen(port, function(){
  console.log('listening on *:3000');
});
